#include <graphics.h>
#include <math.h>

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int cx = 250, cy = 200, r = 100, n = 16;
    float pi = 3.14159;

    for (int i = 0; i < n; i++) {
        float a = 2 * pi * i / n;
        line(cx, cy, cx + (int)(r * cos(a)), cy + (int)(r * sin(a)));
    }

    getch(); closegraph();
    return 0;
}
