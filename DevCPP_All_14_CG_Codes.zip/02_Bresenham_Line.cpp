#include <graphics.h>

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int x1 = 100, y1 = 100, x2 = 400, y2 = 250;
    int dx = x2 - x1, dy = y2 - y1;
    int p = 2 * dy - dx;

    while (x1 <= x2) {
        putpixel(x1, y1, WHITE);
        if (p < 0) {
            p += 2 * dy;
        } else {
            p += 2 * dy - 2 * dx;
            y1++;
        }
        x1++;
    }

    getch(); closegraph();
    return 0;
}
