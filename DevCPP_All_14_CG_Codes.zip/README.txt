============================================================
COMPUTER GRAPHICS PRACTICAL EXAM (DEV-C++ READY - 14 CODES)
============================================================

All 14 codes are shortened, simplified, and verified to compile with 0 errors in Dev-C++.

HOW TO RUN IN DEV-C++:
1. Open any of the .cpp files in Dev-C++.
2. Set the linker parameters:
   Go to: Project -> Project Options -> Parameters -> Linker
   Paste: -lbgi -lgdi32 -lcomdlg32 -luuid -loleaut32 -lole32
3. Hit F11 (Compile and Run).

PROGRAM INDEX:
01_DDA_Line.cpp                 - DDA line algorithm
02_Bresenham_Line.cpp           - Bresenham line algorithm
03_Bresenham_Circle.cpp         - Bresenham / Midpoint circle algorithm
04_Midpoint_Ellipse.cpp         - Midpoint ellipse algorithm (Region 1 & 2)
05_Translation.cpp              - 2D Triangle translation
06_Scaling_Fixed_Point.cpp      - 2D Triangle scaling about fixed point
07_Window_to_Viewport.cpp       - Window to viewport linear mapping
08_Bitmap_Character.cpp         - 5x5 Matrix bitmap character ('A')
09_Boundary_Fill_4_and_8.cpp    - Recursive boundary fill
10_Flood_Fill.cpp               - Recursive flood fill inside solid bar
11_line_clipping.cpp            - Cohen-Sutherland line clipping with region codes
12_floodfill4.cpp               - 4-connected flood fill function
13_starbust.cpp                 - Starburst 16-ray pattern
14_stockcharactergen.cpp        - Stroke character generation ('A')
