#include <graphics.h>

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int x = 200, y = 100, s = 50;

    line(x, y + 3 * s, x + s, y);
    line(x + s, y, x + 2 * s, y + 3 * s);
    line(x + s / 2, y + 2 * s, x + 3 * s / 2, y + 2 * s);

    getch(); closegraph();
    return 0;
}
