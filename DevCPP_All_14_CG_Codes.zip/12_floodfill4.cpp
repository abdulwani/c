#include <graphics.h>

void flood4(int x, int y, int oldC, int newC) {
    if (getpixel(x, y) == oldC) {
        putpixel(x, y, newC);
        flood4(x + 1, y, oldC, newC);
        flood4(x - 1, y, oldC, newC);
        flood4(x, y + 1, oldC, newC);
        flood4(x, y - 1, oldC, newC);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    setfillstyle(SOLID_FILL, BLUE);
    bar(100, 100, 150, 150);
    flood4(120, 120, BLUE, YELLOW);

    getch(); closegraph();
    return 0;
}
