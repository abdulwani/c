#include <graphics.h>
#include <math.h>

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    float x1 = 100, y1 = 100, x2 = 400, y2 = 300;
    float dx = x2 - x1, dy = y2 - y1;
    float steps = (fabs(dx) > fabs(dy)) ? fabs(dx) : fabs(dy);
    float xinc = dx / steps, yinc = dy / steps;

    for (int i = 0; i <= steps; i++) {
        putpixel((int)(x1 + 0.5), (int)(y1 + 0.5), WHITE);
        x1 += xinc;
        y1 += yinc;
    }

    getch(); closegraph();
    return 0;
}
