#include <graphics.h>

void flood(int x, int y) {
    if (getpixel(x, y) == BLUE) {
        putpixel(x, y, YELLOW);
        flood(x + 1, y);
        flood(x - 1, y);
        flood(x, y + 1);
        flood(x, y - 1);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    setfillstyle(SOLID_FILL, BLUE);
    bar(100, 100, 150, 150);
    flood(120, 120); // Seed inside

    getch(); closegraph();
    return 0;
}
