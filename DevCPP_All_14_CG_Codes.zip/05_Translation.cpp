#include <graphics.h>

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");
    int x[] = {100, 150, 200}, y[] = {150, 50, 150}, tx = 120, ty = 80;

    // Original Triangle (White)
    for (int i = 0; i < 3; i++) line(x[i], y[i], x[(i+1)%3], y[(i+1)%3]);

    // Translate & Draw New Triangle (Yellow)
    setcolor(YELLOW);
    for (int i = 0; i < 3; i++) { x[i] += tx; y[i] += ty; }
    for (int i = 0; i < 3; i++) line(x[i], y[i], x[(i+1)%3], y[(i+1)%3]);

    getch(); closegraph();
    return 0;
}
