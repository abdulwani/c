#include <graphics.h>

void fill(int x, int y) {
    if (getpixel(x, y) != WHITE && getpixel(x, y) != YELLOW) {
        putpixel(x, y, YELLOW);
        fill(x + 1, y);
        fill(x - 1, y);
        fill(x, y + 1);
        fill(x, y - 1);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    rectangle(100, 100, 150, 150); // Small box avoids recursion overflow
    fill(120, 120);                 // Seed point inside

    getch(); closegraph();
    return 0;
}
