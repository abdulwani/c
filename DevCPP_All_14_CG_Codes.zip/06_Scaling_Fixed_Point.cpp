#include <graphics.h>

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");
    int x[] = {100, 150, 200}, y[] = {150, 50, 150}, xf = 100, yf = 150;
    float s = 2.0; // scale factor

    // Original Triangle
    for (int i = 0; i < 3; i++) line(x[i], y[i], x[(i+1)%3], y[(i+1)%3]);

    // Scale about (xf, yf)
    setcolor(YELLOW);
    for (int i = 0; i < 3; i++) {
        x[i] = xf + (x[i] - xf) * s;
        y[i] = yf + (y[i] - yf) * s;
    }
    for (int i = 0; i < 3; i++) line(x[i], y[i], x[(i+1)%3], y[(i+1)%3]);

    getch(); closegraph();
    return 0;
}
