#include <graphics.h>

void plot8(int xc, int yc, int x, int y) {
    putpixel(xc+x, yc+y, 15); putpixel(xc-x, yc+y, 15);
    putpixel(xc+x, yc-y, 15); putpixel(xc-x, yc-y, 15);
    putpixel(xc+y, yc+x, 15); putpixel(xc-y, yc+x, 15);
    putpixel(xc+y, yc-x, 15); putpixel(xc-y, yc-x, 15);
}

int main() {
    int gd = DETECT, gm, x = 0, y = 100, d = 3 - 2 * 100;
    initgraph(&gd, &gm, "");

    while (x <= y) {
        plot8(250, 250, x, y);
        if (d < 0) d += 4 * x + 6;
        else { d += 4 * (x - y) + 10; y--; }
        x++;
    }

    getch(); closegraph();
    return 0;
}
