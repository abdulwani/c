#include <graphics.h>

int xmin = 100, ymin = 100, xmax = 400, ymax = 300;

int getCode(int x, int y) {
    int c = 0;
    if (x < xmin) c |= 1;
    if (x > xmax) c |= 2;
    if (y < ymin) c |= 4;
    if (y > ymax) c |= 8;
    return c;
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int x1 = 50, y1 = 150, x2 = 450, y2 = 250;
    int c1 = getCode(x1, y1), c2 = getCode(x2, y2);
    float x, y;

    rectangle(xmin, ymin, xmax, ymax);
    setcolor(RED); line(x1, y1, x2, y2); // Original Line

    while (1) {
        if ((c1 | c2) == 0) break;       // Both inside
        if (c1 & c2) return 0;           // Both outside

        int cOut = c1 ? c1 : c2;
        if (cOut & 8) { x = x1 + (x2 - x1) * (ymax - y1) / (float)(y2 - y1); y = ymax; }
        else if (cOut & 4) { x = x1 + (x2 - x1) * (ymin - y1) / (float)(y2 - y1); y = ymin; }
        else if (cOut & 2) { y = y1 + (y2 - y1) * (xmax - x1) / (float)(x2 - x1); x = xmax; }
        else { y = y1 + (y2 - y1) * (xmin - x1) / (float)(x2 - x1); x = xmin; }

        if (cOut == c1) { x1 = x; y1 = y; c1 = getCode(x1, y1); }
        else { x2 = x; y2 = y; c2 = getCode(x2, y2); }
    }

    setcolor(GREEN);
    line(x1, y1, x2, y2); // Clipped Line

    getch(); closegraph();
    return 0;
}
