#include <graphics.h>

int a[5][5] = {
    {0, 1, 1, 1, 0},
    {1, 0, 0, 0, 1},
    {1, 1, 1, 1, 1},
    {1, 0, 0, 0, 1},
    {1, 0, 0, 0, 1}
};

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++)
            if (a[i][j])
                bar(200 + j * 15, 150 + i * 15, 200 + j * 15 + 12, 150 + i * 15 + 12);

    getch(); closegraph();
    return 0;
}
