#include <graphics.h>

void p4(int xc, int yc, int x, int y) {
    putpixel(xc+x, yc+y, 15); putpixel(xc-x, yc+y, 15);
    putpixel(xc+x, yc-y, 15); putpixel(xc-x, yc-y, 15);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");
    int xc = 300, yc = 200, rx = 120, ry = 70;
    long rx2 = rx * rx, ry2 = ry * ry, x = 0, y = ry;

    // Region 1
    float p1 = ry2 - rx2 * ry + 0.25 * rx2;
    while (2 * ry2 * x < 2 * rx2 * y) {
        p4(xc, yc, x, y);
        x++;
        if (p1 < 0) p1 += 2 * ry2 * x + ry2;
        else { y--; p1 += 2 * ry2 * x - 2 * rx2 * y + ry2; }
    }

    // Region 2
    float p2 = ry2*(x+0.5)*(x+0.5) + rx2*(y-1)*(y-1) - rx2*ry2;
    while (y >= 0) {
        p4(xc, yc, x, y);
        y--;
        if (p2 > 0) p2 += -2 * rx2 * y + rx2;
        else { x++; p2 += 2 * ry2 * x - 2 * rx2 * y + rx2; }
    }

    getch(); closegraph();
    return 0;
}
