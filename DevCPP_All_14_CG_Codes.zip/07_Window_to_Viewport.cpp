#include <graphics.h>

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    float xw1 = 0, yw1 = 0, xw2 = 100, yw2 = 100;       // Window
    float xv1 = 150, yv1 = 150, xv2 = 350, yv2 = 350;   // Viewport
    float x = 50, y = 50;                               // Point inside window

    float xv = xv1 + (x - xw1) * (xv2 - xv1) / (xw2 - xw1);
    float yv = yv1 + (y - yw1) * (yv2 - yv1) / (yw2 - yw1);

    rectangle(xv1, yv1, xv2, yv2); // Viewport Box
    circle(xv, yv, 5);             // Mapped Point

    getch(); closegraph();
    return 0;
}
